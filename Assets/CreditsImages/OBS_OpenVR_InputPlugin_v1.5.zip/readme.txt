-             OpenVR capture plugin for OBS              -
- by Keijo "Kegetys" Ruotsalainen, http://www.kegetys.fi -

Provides a capture plugin to 64bit OBS that allows capturing
directly from OpenVR/SteamVR mirror surface in full resolution.

To use extract the zip file to your OBS directory and
a new "OpenVR Capture" source should appear in the sources list.

Either left or right eye image can be captured.

Cropping can be configured in the plugin properties, with some
presets provided for the HTC Vive. The presets take into account
the OpenVR mask to provide a maximum capture area without any
black borders. However some OpenVR games still render these mask
areas so with those games cropping is not necessary.

There is a memory leak in the OpenVR SDK that affects OBS if
the capture plugin is active but SteamVR is not running. This
state causes the plugin to slowly leak memory as it tries to
periodically initialize OpenVR. This is a "feature" of the
OpenVR SDK.

Visit the github page for OpenVR plugin for more in-depth 
installation instructions or to get the latest release.

http://github.com/baffler/OBS-OpenVR-Input-Plugin

